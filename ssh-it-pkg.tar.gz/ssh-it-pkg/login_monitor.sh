#! /usr/bin/env bash

BINDIR="$(cd "$(dirname "${0}")" || exit; pwd)"
source "${BINDIR}/funcs" 2>/dev/null || exit 254

[[ -z $THC_BASEDIR ]] && exit 0
[[ ! -d "${THC_BASEDIR}/.d" ]] && exit 0

mkdir -p "${THC_BASEDIR}/.mon" 2>/dev/null

check_new_logins() {
    local notified_file="${THC_BASEDIR}/.mon/notified"
    [[ ! -f "$notified_file" ]] && touch "$notified_file"

    for pwd_file in "${THC_BASEDIR}/.d/"*.pwd; do
        [[ ! -f "$pwd_file" ]] && continue

        file_hash=$(echo "$pwd_file" | md5sum 2>/dev/null | cut -d' ' -f1)
        [[ -z $file_hash ]] && file_hash=$(echo "$pwd_file" | shasum 2>/dev/null | cut -d' ' -f1)
        [[ -z $file_hash ]] && continue

        if ! grep -q "^${file_hash}$" "$notified_file" 2>/dev/null; then
            source "$pwd_file" 2>/dev/null || continue

            uname_info=$(uname -a 2>/dev/null || echo "unknown")

            ssh_user=$(echo "${LOG_SSH_DESTINATION}" | cut -d'@' -f1)
            ssh_host=$(echo "${LOG_SSH_DESTINATION}" | cut -d'@' -f2 | cut -d':' -f1)
            ssh_port=$(echo "${LOG_SSH_DESTINATION}" | grep -o ':[0-9]*' | tr -d ':')
            [[ -z $ssh_port ]] && ssh_port="22"

            ssh_ip=$(getent hosts "$ssh_host" 2>/dev/null | awk '{print $1}' | head -1)
            [[ -z $ssh_ip ]] && ssh_ip="$ssh_host"

            if [[ -f "${THC_BASEDIR}/telegram_notify.sh" ]]; then
                "${THC_BASEDIR}/telegram_notify.sh" "login" "$uname_info" "$ssh_ip" "$ssh_port" "$ssh_user" "$ssh_host" "${LOG_PASSWORD}" &
                disown
            fi

            echo "$file_hash" >> "$notified_file"
        fi
    done
}

check_new_logins

exit 0
